import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, RefreshCw } from 'lucide-react';
import { useCheckStore } from '../store/checkStore';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import CheckImageViewer from '../components/check/CheckImageViewer';
import CheckDetailPanel from '../components/check/CheckDetailPanel';
import { formatCurrency } from '../utils/formatters';
import { CheckData } from '../types';
import { useSimulatorControl } from '../context/SimulatorControlContext';

const CheckList: React.FC = () => {
  const navigate = useNavigate();
  const { checks, fetchChecks, selectCheck } = useCheckStore();
  const [selectedCheck, setSelectedCheck] = useState<CheckData | null>(null);
  const { sendCommand } = useSimulatorControl();

  const handleScan = () => {
    sendCommand('SCAN');
  };

  const handleReset = () => {
    setSelectedCheck(null);
  };

  const handleDelete = (id: string) => {
    console.log('Delete not implemented yet');
  };

  const totalAmount = checks.reduce((sum, check) => sum + (check.amount || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-primary-600 text-white">
        <Button variant="ghost" onClick={() => navigate(-1)} className="text-white">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Retour
        </Button>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleScan}
            className="bg-white text-primary-600"
          >
            <Plus className="h-4 w-4 mr-2" />
            Numériser
          </Button>
          <Button
            variant="outline"
            onClick={handleReset}
            className="bg-gray-100 text-gray-700"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Remise à zéro
          </Button>
        </div>
      </div>
  
      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Colonne 1 : Détail du chèque */}
        <div className="col-span-3">
          {selectedCheck && (
            <Card>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Détails du Chèque</h3>
                  <Button
                    variant="outline"
                    color="danger"
                    size="sm"
                    onClick={() => handleDelete(selectedCheck.id)}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Supprimer
                  </Button>
                </div>
                <CheckImageViewer images={selectedCheck.images} />
                <CheckDetailPanel check={selectedCheck} />
              </div>
            </Card>
          )}
        </div>
  
        {/* Colonne 2-3 : Remise et Liste */}
        <div className="col-span-1 lg:col-span-2 flex flex-col gap-6">
          
          {/* Résumé */}
          <Card className="self-center">
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Remises Client</h3>
              <div className="space-y-2">
                <p className="text-sm">
                  Nb Chèques Numérisés : <strong>{checks.length}</strong>
                </p>
                <p className="text-sm">
                  Montant Total : <strong>{formatCurrency(totalAmount)}</strong>
                </p>
              </div>
            </div>
          </Card>
  
          {/* Liste des chèques */}
          <Card className="self-center">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr>
                    <th className="px-4 py-2 text-left">Image</th>
                    <th className="px-4 py-2 text-left">Numéro</th>
                    <th className="px-4 py-2 text-left">Montant</th>
                   
                  </tr>
                </thead>
                <tbody>
                  {checks.map((check) => (
                    <tr
                      key={check.id}
                      className={`hover:bg-gray-50 ${
                        check.status === 'validated'
                          ? 'bg-green-50'
                          : check.status === 'needs_review'
                          ? 'bg-yellow-50'
                          : check.status === 'rejected'
                          ? 'bg-red-50'
                          : ''
                      }`}
                      onClick={() => setSelectedCheck(check)}
                    ><td className="px-4 py-2">
                    <img
                      src={check.images[0]?.url}
                      alt={`Chèque ${check.checkNumber}`}
                      className="w-20 rounded"
                    />
                  </td>
                      <td className="px-4 py-2">{check.checkNumber}</td>
                      <td className="px-4 py-2">{formatCurrency(check.amount)}</td>
                
                      
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
  
        </div>
      </div>
    </div>  
  );
};

export default CheckList;
