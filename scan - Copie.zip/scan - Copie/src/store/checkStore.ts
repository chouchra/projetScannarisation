import { create } from 'zustand';
import { CheckData, CheckStatus, FilterOption, Pagination, SortOption, CheckImage } from '../types';
import { mockChecks } from '../utils/mockData';


interface CheckState {
  checks: CheckData[];
  selectedCheckId: string | null;
  isLoading: boolean;
  error: string | null;
  pagination: Pagination;
  sort: SortOption;
  filters: FilterOption[];
  searchTerm: string;
  
  // Actions
  fetchChecks: () => Promise<void>;
  selectCheck: (id: string | null) => void;
  updateCheckStatus: (id: string, status: CheckStatus) => Promise<void>;
  setSortOption: (sort: SortOption) => void;
  setFilter: (filter: FilterOption) => void;
  removeFilter: (field: string) => void;
  clearFilters: () => void;
  setSearchTerm: (term: string) => void;
  setPage: (page: number) => void;
  addCheck: (check: CheckData) => void;
}

export const useCheckStore = create<CheckState>((set, get) => ({
  checks: [],
  selectedCheckId: null,
  isLoading: false,
  error: null,
  pagination: {
    page: 1,
    limit: 10,
    total: 0,
  },
  sort: {
    field: 'createdAt',
    direction: 'desc',
  },
  filters: [],
  searchTerm: '',
  
  fetchChecks: async () => {
    set({ isLoading: true, error: null });
    try {
      // In a real app, this would be an API call
      // For now, we'll use our mock data
      const data = mockChecks;
      
      // Apply pagination
      const { page, limit } = get().pagination;
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      
      // Apply sorting
      const { field, direction } = get().sort;
      const sortedData = [...data].sort((a, b) => {
        const aValue = a[field as keyof CheckData];
        const bValue = b[field as keyof CheckData];
        
        if (typeof aValue === 'string' && typeof bValue === 'string') {
          return direction === 'asc' 
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          return direction === 'asc' ? aValue - bValue : bValue - aValue;
        }
        
        return 0;
      });
      
      // Get current state from store
      const { checks, filters, searchTerm } = get();
      
      // Apply filtering
      const filteredChecks = checks.filter((check: CheckData) => {
        const searchLower = searchTerm.toLowerCase();
        
        if (searchLower) {
          const matchesSearch = 
            check.checkNumber.toLowerCase().includes(searchLower) ||
            check.payee.name.toLowerCase().includes(searchLower) ||
            check.issuer.name.toLowerCase().includes(searchLower) ||
            check.bankDetails.accountNumber.includes(searchLower);
          
          if (!matchesSearch) return false;
        }
        
        // Apply filters if present
        return filters.every((filter: FilterOption) => {
          const value = check[filter.field as keyof CheckData];
          
          // Handle string values with contains operator
          if (value !== undefined && typeof value === 'string' && filter.operator === 'contains' && filter.value !== undefined) {
            return value.toLowerCase().includes(filter.value.toString().toLowerCase());
          }
          
          // Handle exact match for other types
          if (value === undefined || filter.value === undefined) return false;
          
          switch (filter.operator) {
            case 'eq':
              return value === filter.value;
            case 'neq':
              return value !== filter.value;
            case 'gt':
              return value > filter.value;
            case 'gte':
              return value >= filter.value;
            case 'lt':
              return value < filter.value;
            case 'lte':
              return value <= filter.value;
            default:
              return false;
          }
        });
      });
      
      // Get paginated results
      const paginatedData = filteredChecks.slice(startIndex, endIndex);
      
      set({ 
        checks: paginatedData,
        isLoading: false,
        pagination: {
          ...get().pagination,
          total: filteredChecks.length
        },
      });
    } catch (error) {
      console.error('Error fetching checks:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch checks' 
      });
    }
  },
  
  selectCheck: (id: string | null) => {
    set({ selectedCheckId: id });
  },
  
  updateCheckStatus: async (id: string, status: CheckStatus) => {
    set({ isLoading: true, error: null });
    try {
      // In a real app, this would be an API call
      // For now, we'll update our local state
      const updatedChecks = get().checks.map(check => 
        check.id === id ? { ...check, status, updatedAt: new Date().toISOString() } : check
      );
      
      set({ checks: updatedChecks, isLoading: false });
    } catch (error) {
      console.error('Error updating check status:', error);
      set({ 
        isLoading: false, 
        error: error instanceof Error ? error.message : 'Failed to update check status' 
      });
    }
  },
  
  setSortOption: (sort: SortOption) => {
    set({ sort });
    get().fetchChecks();
  },
  
  setFilter: (filter: FilterOption) => {
    const filters = get().filters.filter(f => f.field !== filter.field);
    set({ filters: [...filters, filter] });
    get().fetchChecks();
  },
  
  removeFilter: (field: string) => {
    set({ filters: get().filters.filter(f => f.field !== field) });
    get().fetchChecks();
  },
  
  clearFilters: () => {
    set({ filters: [] });
    get().fetchChecks();
  },
  
  setSearchTerm: (term: string) => {
    set({ searchTerm: term });
    get().fetchChecks();
  },
  
  setPage: (page: number) => {
    set({ pagination: { ...get().pagination, page } });
    get().fetchChecks();
  },



  addCheck: (check: CheckData) => {
    const current = get();
    const newChecks = [...current.checks, check];
  
    set({
      checks: newChecks,
      pagination: {
        ...current.pagination,
        total: current.pagination.total + 1,
      },
    });
  } ,
}));