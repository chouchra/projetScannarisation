// Check related types
export interface CheckImage {
  id: string;
  url: string;
  type: 'recto' | 'verso' | 'uv';
  width: number;
  height: number;
  createdAt: string;
}

export interface BankDetails {
  bankCode: string;      // 3 digits
  branchCode: string;    // 3 digits
  accountNumber: string; // 16 digits
  routingNumber: string; // Routing number
  ribKey: string;       // 2 digits
  bankName: string;
  branchAddress?: string;
}

export interface CheckData {
  id: string;
  checkNumber: string;
  amount: number;
  amountInWords: string;
  payee: {
    name: string;
    identifier?: string; // National ID or passport number
  };
  issuer: {
    name: string;
    address?: string;
    phone?: string;
  };
  bankDetails: BankDetails;
  date: string;
  memo?: string;
  status: CheckStatus;
  currency: string;
  securityFeatures: {
    hasWatermark: boolean;
    hasMicrotext: boolean;
    hasUVFeatures: boolean;
  };
  verificationDetails?: {
    verifiedAt?: string;
    verifiedBy?: string;
    notes?: string;
  };
  images: CheckImage[];
  createdAt: string;
  updatedAt: string;
}

export type CheckStatus = 
  | 'pending'
  | 'validated'
  | 'rejected'
  | 'needs_review';

// User related types
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export type UserRole = 
  | 'admin'
  | 'operator'
  | 'viewer';

// Application state types
export interface Pagination {
  page: number;
  limit: number;
  total: number;
}

export interface SortOption {
  field: string;
  direction: 'asc' | 'desc';
}

export interface FilterOption {
  field: string;
  value: string | number | boolean;
  operator: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains';
}

export interface QueryOptions {
  pagination: Pagination;
  sort?: SortOption;
  filters?: FilterOption[];
  search?: string;
}