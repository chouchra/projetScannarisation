import React, { createContext, useContext, useEffect } from 'react';
import { useCheckStore } from '../store/checkStore';
import { CheckData } from '../types/index';
import { v4 as uuidv4 } from 'uuid';

const ScannerDataContext = createContext({});

export const ScannerDataProvider = ({ children }: { children: React.ReactNode }) => {
  const { addCheck } = useCheckStore();

  useEffect(() => {
    const ws = new WebSocket('ws://localhost:8080/scanner');

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        const check: CheckData = {
          id: uuidv4(),
          checkNumber: data.chequeNumber || '',
          amount: parseFloat((data.amount || '0.00').replace(' EUR', '')),
          amountInWords: '', // Optional if available
          currency: 'MAD',
          date: data.scanDate || new Date().toISOString(),
          memo: data.rawData || '',
          status: 'pending',
          payee: { name: 'Client inconnu' },
          issuer: { name: 'Inconnu' },
          bankDetails: {
            bankCode: '001',
            branchCode: '001',
            accountNumber: '0000000000000000',
            routingNumber: '',
            ribKey: '00',
            bankName: 'Banque inconnue',
          },
          securityFeatures: {
            hasWatermark: false,
            hasMicrotext: false,
            hasUVFeatures: !!data.image3,
          },
          images: [
            {
              id: uuidv4(),
              url: `data:image/jpeg;base64,${data.image1}`,
              type: 'recto',
              width: 400,
              height: 150,
              createdAt: new Date().toISOString(),
            },
            {
              id: uuidv4(),
              url: `data:image/jpeg;base64,${data.image2}`,
              type: 'verso',
              width: 400,
              height: 150,
              createdAt: new Date().toISOString(),
            },
            {
              id: uuidv4(),
              url: `data:image/jpeg;base64,${data.image3}`,
              type: 'uv',
              width: 400,
              height: 150,
              createdAt: new Date().toISOString(),
            },
          ].filter(img => img.url), // remove empty if missing
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        addCheck(check);
      } catch (error) {
        console.error('Erreur lors du traitement du scan :', error);
      }
    };

    ws.onopen = () => {
      console.log('✅ Connecté au flux du scanner');
    };

    ws.onerror = (err) => {
      console.error('🚨 Erreur WebSocket scanner', err);
    };

    ws.onclose = () => {
      console.log('❌ Connexion WebSocket scanner fermée');
    };

    return () => ws.close();
  }, [addCheck]);

  return <ScannerDataContext.Provider value={{}}>{children}</ScannerDataContext.Provider>;
};

export const useScannerData = () => useContext(ScannerDataContext);
