package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.MemoryCacheImageOutputStream;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;

public class SimulatedScanner {

    private static ScannerWebSocketClient scannerClient;

    public static void main(String[] args) throws Exception {
        // Connect to backend to send data
        scannerClient = new ScannerWebSocketClient(new URI("ws://localhost:8080/scanner"));
        scannerClient.connectBlocking();

        // Connect to backend to receive commands
        CommandListenerWebSocketClient commandClient = new CommandListenerWebSocketClient(new URI("ws://localhost:8080/simulator-control"));
        commandClient.connectBlocking();

        System.out.println("✅ Simulateur prêt. En attente des commandes depuis le frontend...");
    }

    // Méthode pour simuler une numérisation
    public static void triggerScan() {
        try {
            Map<String, Object> simulatedData = new HashMap<>();
            simulatedData.put("chequeNumber", String.valueOf((int) (Math.random() * 900000) + 100000));
            simulatedData.put("amount", "0.00 EUR");
            simulatedData.put("date", "");
            simulatedData.put("cmc7", "CMC7-" + (int) (Math.random() * 1000000));
            simulatedData.put("scanDate", LocalDateTime.now().toString());
            simulatedData.put("rawData", "Simulated OCR data from cheque.");
            simulatedData.put("image1", processAndEncodeImage("resources/cheque.jpg"));
            simulatedData.put("image2", processAndEncodeImage("resources/cheque2.jpg"));
            simulatedData.put("image3", processAndEncodeImage("resources/cheque3.jpg"));

            ObjectMapper mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(simulatedData);

            scannerClient.send(json);
            System.out.println("📤 Données du chèque envoyées !\n"+ json+"\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Redimensionner et compresser une image en base64
    private static String processAndEncodeImage(String path) throws Exception {
        BufferedImage originalImage = ImageIO.read(Paths.get(path).toFile());
        int width = 300, height = 200;
        Image scaled = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = resized.createGraphics();
        g2d.drawImage(scaled, 0, 0, null);
        g2d.dispose();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpg").next();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(0.7f);
        writer.setOutput(new MemoryCacheImageOutputStream(baos));
        writer.write(null, new javax.imageio.IIOImage(resized, null, null), param);
        writer.dispose();

        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }

    // WebSocket pour l'envoi des données
    static class ScannerWebSocketClient extends WebSocketClient {
        public ScannerWebSocketClient(URI serverUri) {
            super(serverUri);
        }

        public void onOpen(ServerHandshake handshake) {
            System.out.println("✅ Connecté au WebSocket d'envoi.");
        }

        public void onMessage(String message) {}

        public void onClose(int code, String reason, boolean remote) {
            System.out.println("❌ Fermeture de connexion : " + reason);
        }

        public void onError(Exception ex) {
            System.err.println("🚨 Erreur d'envoi : " + ex.getMessage());
        }
    }

    // WebSocket pour recevoir les commandes (ex: "SCAN")
    static class CommandListenerWebSocketClient extends WebSocketClient {
        public CommandListenerWebSocketClient(URI serverUri) {
            super(serverUri);
        }

        public void onOpen(ServerHandshake handshake) {
            System.out.println("✅ Connecté au WebSocket de commande.");
        }

        public void onMessage(String message) {
            System.out.println("📩 Commande reçue : " + message);
            if (message.contains("\"command\":\"SCAN\"")) {
                triggerScan();
            }
        }

        public void onClose(int code, String reason, boolean remote) {
            System.out.println("❌ WebSocket commande fermé : " + reason);
        }

        public void onError(Exception ex) {
            System.err.println("🚨 Erreur WebSocket commande : " + ex.getMessage());
        }
    }
}
