package org.example;

import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SimulatorControlHandler extends TextWebSocketHandler {

    private static final Set<WebSocketSession> sessions = Collections.synchronizedSet(new HashSet<>());

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        sessions.add(session);
        System.out.println("✅ Simulateur connecté au canal de commande.");
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        sessions.remove(session);
        System.out.println("❌ Simulateur déconnecté.");
    }

    // Appelé quand le frontend envoie une commande
    @Override
    public void handleTextMessage(WebSocketSession senderSession, TextMessage message) throws Exception {
        System.out.println("📩 Commande frontend reçue : " + message.getPayload());

        // Rediffuse la commande à tous les simulateurs connectés
        synchronized (sessions) {
            for (WebSocketSession session : sessions) {
                if (session.isOpen()) {
                    session.sendMessage(message);
                }
            }
        }
    }
}
