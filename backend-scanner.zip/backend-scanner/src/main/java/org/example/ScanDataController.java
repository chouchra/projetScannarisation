package org.example;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Queue;

@RestController
public class ScanDataController {

    @GetMapping("/api/scans")
    public Queue<ScanData> getAllScans() {
        return ScannerWebSocketHandler.getScanDataQueue();
    }
}
