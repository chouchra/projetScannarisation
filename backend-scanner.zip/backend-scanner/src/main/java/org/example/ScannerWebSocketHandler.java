package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ScannerWebSocketHandler extends TextWebSocketHandler {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final Set<WebSocketSession> sessions = Collections.synchronizedSet(new HashSet<>());
    private static final Queue<ScanData> scanDataQueue = new ConcurrentLinkedQueue<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        sessions.add(session);
        System.out.println("🔗 Nouvelle connexion WebSocket. Total : " + sessions.size());
    }

    //@Override
    public void handleTextMessageOld(WebSocketSession session, TextMessage message) {
        try {
            String payload = message.getPayload();
            ScanData data = objectMapper.readValue(payload, ScanData.class);
            scanDataQueue.add(data);

            System.out.println("✅ Données Scanner Reçues : " + data.chequeNumber);

            broadcastToAllClients(payload);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, org.springframework.web.socket.CloseStatus status) {
        sessions.remove(session);
        System.out.println("❌ Connexion fermée. Total : " + sessions.size());
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) {
        try {
            String payload = message.getPayload();

            // broadcast à tous, même ceux qui ne sont pas l'émetteur
            for (WebSocketSession wsSession : sessions) {
                if (wsSession.isOpen()) {
                    wsSession.sendMessage(new TextMessage(payload));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void broadcastToAllClients(String message) {
        synchronized (sessions) {
            for (WebSocketSession clientSession : sessions) {
                try {
                    if (clientSession.isOpen()) {
                        clientSession.sendMessage(new TextMessage(message));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // API pour récupérer l'historique des scans
    public static Queue<ScanData> getScanDataQueue() {
        return scanDataQueue;
    }
}
