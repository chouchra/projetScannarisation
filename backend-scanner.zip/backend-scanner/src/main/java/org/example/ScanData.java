package org.example;


public class ScanData {
    public String chequeNumber;
    public String amount;
    public String date;
    public String cmc7;
    public String scanDate;
    public String rawData;
    public String image1;
    public String image2;
    public String image3;
}
